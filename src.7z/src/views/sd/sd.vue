<script setup lang="ts">
</script>

<template>
  <div class="h-full">
    <iframe style="width: 100%;height: 100%;" src="http://172.18.35.26:7860" frameborder="0" />
  </div>
</template>
